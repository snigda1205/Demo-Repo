import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtc.app.entity.Person;

import com.mtc.app.util.HibernateUtil;

public class TestPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
				SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
				Session session=sessionFactory.openSession();
				Person p=new Person(10,"ramu",12,"ram@g.com");
				
				Transaction tran=session.getTransaction();
				tran.begin();
				//session.save(p);
				session.update(p);
				tran.commit();
				session.close();
				
				
			
			
			}

		

	}

