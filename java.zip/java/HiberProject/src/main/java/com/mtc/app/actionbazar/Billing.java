package com.mtc.app.actionbazar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity

//table name is not required as class name is itself table name, hibernate understands like thats
public class Billing {
	
	@Id
	private Long billingId;
	@OneToOne
	@JoinColumn(name="address_id")
	private Address addressId;
	
}
