package com.mtc.app.actionbazar;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;


@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="inventory")
@Entity
@Table(name="item")
public class Item  implements Serializable{
	@Id
	@Column(name="id")
	private Long itemId;
	@Column(name="name")
	private String itemName;
	@Column(name="date")
	
	
	private LocalDate createdDate;
	@Column(name="initial_price")
	private BigDecimal intitialPrice;
	
	@Column(name="bid_start_date")
	
	private LocalDate bidStartDate;
	
	@Column(name="bid_end_date")
	
	private LocalDate bidEndDate;
	
	public Set<Bid> getBid() {
		return bid;
	}
	public void setBid(Set<Bid> bid) {
		this.bid = bid;
	}
	@OneToMany(cascade=CascadeType.ALL)
	//@OneToMany(mappedBy="item"cascade=CascadeType.ALL)--for bidirectional
	@JoinColumn(name="id")// maps associations
	private Set<Bid> bid;// association 
	
	 @OneToOne(mappedBy="item")
	 private Order order;
	 
	 @ManyToMany// giving join column details
	 @JoinTable(name="categories_items",joinColumns= {@JoinColumn(name="item_id")}, inverseJoinColumns= {@JoinColumn(name="category_id")})
	 private Set<Category> categories;
	 
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Item()
	{
		
	}
	
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public LocalDate getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}
	public BigDecimal getIntitialPrice() {
		return intitialPrice;
	}
	public void setIntitialPrice(BigDecimal intitialPrice) {
		this.intitialPrice = intitialPrice;
	}
	public LocalDate getBidStartDate() {
		return bidStartDate;
	}
	public void setBidStartDate(LocalDate bidStartDate) {
		this.bidStartDate = bidStartDate;
	}
	public LocalDate getBidEndDate() {
		return bidEndDate;
	}
	public void setBidEndDate(LocalDate bidEndDate) {
		this.bidEndDate = bidEndDate;
	}
	public Item(Long itemId, String itemName, LocalDate createdDate, BigDecimal intitialPrice, LocalDate bidStartDate,
			LocalDate bidEndDate, Set<Bid> bid) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.createdDate = createdDate;
		this.intitialPrice = intitialPrice;
		this.bidStartDate = bidStartDate;
		this.bidEndDate = bidEndDate;
		this.bid = bid;
	}
}
	
