package com.mtc.app.actionbazar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="order")
public class Order {
	@Id
	@Column(name="order_id")
	private Long orderId;
	@Column(name="order_status")
	//private OrderStatus orderStatus;
	@OneToOne
	@JoinColumn(name="item_id")
	private Item item;
	@OneToOne
	@JoinColumn(name="billing_id")
	private Billing billing_id;
	
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/*public OrderStatus getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}*/

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Billing getBilling_id() {
		return billing_id;
	}

	public void setBilling_id(Billing billing_id) {
		this.billing_id = billing_id;
	}
public Order () {
	
}
	public Order(Long orderId,   Item item, Billing billing_id) {
		super();
		this.orderId = orderId;
		//this.orderStatus = orderStatus;
		this.item = item;
		this.billing_id = billing_id;
	}
	

}
