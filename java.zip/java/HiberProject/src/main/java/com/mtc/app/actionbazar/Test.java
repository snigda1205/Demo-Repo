package com.mtc.app.actionbazar;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtc.app.entity.Person;
import com.mtc.app.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		
		Item item=new Item();
		item.setItemId(1L);
		item.setBidStartDate(LocalDate.of(2018, 4, 13));
		item.setBidEndDate(LocalDate.of(2018, 4, 18));
		item.setCreatedDate(LocalDate.of(2018, 4, 13));
		item.setIntitialPrice(new BigDecimal(200));
		item.setItemName("iphone");
		Set<Bid> bid=new HashSet<Bid>();
		bid.add(new Bid(1L, 300, LocalDate.of(2018, 4, 16)));
		bid.add(new Bid(2L, 300, LocalDate.of(2018, 4, 17)));
		bid.add(new Bid(3L, 300, LocalDate.of(2018, 4, 16)));
		
		item.setBid(bid);
		session.save(item);
		Transaction tran=session.getTransaction();
		tran.begin();
	
		
		tran.commit();
		session.close();
	
	}

}
