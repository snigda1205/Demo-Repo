package com.mtc.app.actionbazar;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="creditCrad")
public class CreditCard {

}
