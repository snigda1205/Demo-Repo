package com.mtc.app.actionbazar;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="bid")
public class Bid {
	@Id
	@Column(name="bid_id")
	private Long bidId;
	@Column(name="bid_price")
	private int bidPrice;
	@Column(name="bid_date")

	private LocalDate bidDate;
	/*@MnayToOne---for bidirectional code
	 * JoinColumn(name="item_id")
	 * private Item item;
	
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}*///item enity describes manytoone associations
	public Long getBidId() {
		return bidId;
	}
	public void setBidId(Long bidId) {
		this.bidId = bidId;
	}
	public int getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(int bidPrice) {
		this.bidPrice = bidPrice;
	}
	public LocalDate getBidDate() {
		return bidDate;
	}
	public void setBidDate(LocalDate bidDate) {
		this.bidDate = bidDate;
	}
	public Bid(Long bidId, int bidPrice, LocalDate bidDate) {
		super();
		this.bidId = bidId;
		this.bidPrice = bidPrice;
		this.bidDate = bidDate;
	}
	
	

	
}
