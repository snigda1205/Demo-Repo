import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> names=new LinkedList<>();

		names.add("rama");
		names.add("ram");
		names.add("sita");
		names.add("siya");
		names.add("rami");
		LinkedList<String> names2=new LinkedList<>();
		names2.add("riya");
		names2.add("ramki");
		names2.add("sima");
		names2.add("seya");
		names2.add("rami");
		//names.addAll(names2);
		//names.removeAll(names2)	;
		//names.retainAll(names2);
		/*for(String str:names)
		{
			System.out.println(str);
		}*/
		Iterator<String> a=names.iterator();// obtain iterator object refrence 
		while(a.hasNext())
		{
			System.out.println(a.next());
			System.out.println();
		}
	}

}
