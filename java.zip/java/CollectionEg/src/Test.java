import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> names=new ArrayList<>();

	names.add("rama");
	names.add("ram");
	names.add("sita");
	names.add("siya");
	names.add("rami");
	System.out.println("no of elements " +names.size());
	System.out.println(names.contains("siya"));
	String [] namesArray=new String[names.size()];// size is 4,string must be given size
	names.toArray(namesArray);//creates an object of type string
	
	for (String str:namesArray)
		{
		System.out.println(str);
		}
		}
	

}
