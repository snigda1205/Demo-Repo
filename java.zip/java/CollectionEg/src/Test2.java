import java.util.LinkedList;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> names=new LinkedList<>();

		names.add("rama");
		names.add("ram");
		names.add("sita");
		names.add("siya");
		names.add("rami");
		//names.set(2, "Charles" );
		names.remove(2);
		for(String str: names)
		{
			System.out.println(str);
		}

	}

}
