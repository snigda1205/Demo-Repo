import java.util.ArrayList;
import java.util.List;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Test {
	
	
	public static void addProduct(Product product) throws ClassNotFoundException
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		String insertQuery="insert into test.product(id,description,name,price)"+ "values(?,?,?,?)";		
		try
		{
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","snigda","root");
			PreparedStatement prep=con.prepareStatement(insertQuery);
			prep.setInt(1, product.getId());
			prep.setString(3, product.getName());
			prep.setFloat(4, product.getPrice());
			prep.setString(2, product.getDescription());
			int noOfRows=prep.executeUpdate();
		if(noOfRows==1)
		{
			System.out.println("rows are  added ");
		}
		con.close();
		}
		catch(Exception e)
		{
			
		}
	}

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
        Product p=new Product(2, "a1", "abc", 2);
        addProduct(p);
       
        
	}

}
