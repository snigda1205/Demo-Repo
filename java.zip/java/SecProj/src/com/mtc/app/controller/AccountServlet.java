package com.mtc.app.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mtc.app.entity.User;

/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter pw=response.getWriter();
	pw.println("<h2>Home page</h2>");
	//User user=(User)request.getAttribute("user");
	ServletContext	sc=request.getServletContext();
	User user=(User)sc.getAttribute("user");
	//presentation logic
	pw.println("<h2>User Records</h2>");
	pw.println("<p> User Name: "+user.getUsername()+"</p>");
	pw.println("<p> Fisrt Name : "+user.getFirstname()+"</p>");
	pw.println("<p> Email: "+user.getEmail()+"</p>");
	pw.println("<p> Gender : "+user.getGender()+"</p>");
	}

}
