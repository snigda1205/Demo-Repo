package com.mtc.app.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mtc.app.dao.UserDao;
import com.mtc.app.entity.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginProcess")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		UserDao userDao=new UserDao();
		User user=userDao.loadByUser(username);
		
		if(user!=null)
		{
			if(user.getPassword().equals(password))
			{
				//request.setAttribute("user", user);
				ServletContext	sc=request.getServletContext();
				sc.setAttribute("user", user);
				RequestDispatcher dispatcher=request.getRequestDispatcher("AccountServlet");
				dispatcher.forward(request, response);
			}
		
		else
		{
			RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
			dispatcher.forward(request, response);
		}
		}
			else
			{
				request.setAttribute("unamerror", "username is invalid");
				RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
				dispatcher.forward(request, response);
			}
		}
	}


