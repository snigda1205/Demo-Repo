package com.mtc.app.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mtc.app.entity.User;
import com.mtc.app.util.HibernateUtil;

public class UserDao {
	private SessionFactory sessionFactory;
	
	public UserDao()
	{
		sessionFactory=HibernateUtil.getSessionFactory();
			
	}
public User loadByUser(String username)
{
	Session session=sessionFactory.openSession();
User user=session.get(User.class, username);
return user;
}
}
