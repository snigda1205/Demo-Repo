
public  class ThreadRun implements Runnable{

@Override
public void run()
{
	System.out.println("runnable");
}
}
