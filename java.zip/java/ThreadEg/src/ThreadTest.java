
public class ThreadTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread a=Thread.currentThread();
		
		System.out.println(a.getName());
Thread.sleep(40);
System.out.println("end of main");
	}

}
