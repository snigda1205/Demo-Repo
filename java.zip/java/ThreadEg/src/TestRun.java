
public class TestRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread thread=new Thread(new ThreadRun());
thread.setName("sample");
thread.start();
	}

}
