
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SampleThread a=new SampleThread();
a.setName("sample");
a.start();
SampleThread a1=new SampleThread();
a1.setName("sample2");
a1.start();
	}

}
