import org.hibernate.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory s=HibernateUtil.getSessionFactory();
		Session session=s.openSession();
		
		
		Product p=new Product("xyz","ABC",100);
		
		Transaction tran=session.getTransaction();
		tran.begin();
		session.save(p);
		session.update(p);
		tran.commit();
		session.close();
		s.close();
		
		

	}

}
