package com.mtc.app.util;


import org.hibernate.HibernateException; 
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mtc.app.entity.Product;

public class HibernateUtil {
	private final static SessionFactory SESSION_FACTORY;
	
		static
		{
			Configuration config =new Configuration();
			
			//loads hibernate.cfg.xml
		config.configure();
		
		 config.addAnnotatedClass(Product.class);
		 
		//starts hibernate services essential to work with hibernate framework
		ServiceRegistry sr=new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
	
		
		SESSION_FACTORY=config.buildSessionFactory(sr);
		
		
		}
		public static SessionFactory getSessionFactory()
		{
			return SESSION_FACTORY;
			
		}
	}


