import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.mtc.app.util.HibernateUtil;



import org.hibernate.query.Query;
import com.mtc.app.entity.Product;

public class TestHQL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
	// Query<Product> query=session.createQuery("select a from Product a where a.id>5 and a.price>50");// here product is class name its table name
	// Query<Product> query=session.createQuery("select a from Product a where a.id> ? and a.price> ?");//bind parameters
		Query<Product> query=session.createQuery("select a from Product a where a.id> :aid and a.price> aprice");//bind parameters
			query.setParameter("aid", 11);
	 
	 List <Product> p=query.list();
	System.out.println(p.toString());
	p.stream().forEach(System.out::println);
	session.close();
	sessionFactory.close();
	}

}
