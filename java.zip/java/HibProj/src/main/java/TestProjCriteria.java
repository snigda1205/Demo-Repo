import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class TestProjCriteria {

	private static final String Query = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory s=HibernateUtil.getSessionFactory();
		Session session=s.openSession();
		CriteriaBuilder c=s.getCriteriaBuilder();
		CriteriaQuery<Object[]> p=c.createQuery(Object[].class);//we are using projecctions , so we use object array
Root<Product> root= p.from(Product.class);
p.multiselect(root.<String>get("name"),root.<Float>get("price"));// here p is criteria which specifies the details
 Query<Object[]> query=session.createQuery(p);
List<Object[]> alist=query.list();
for(Object[] o:alist )
{
	System.out.println("name: "+o[0]);
	System.out.println("price: "+o[1]);
	
}
s.close();
session.close();

	}
}
