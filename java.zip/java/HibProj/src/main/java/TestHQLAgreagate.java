import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class TestHQLAgreagate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();

		Query<Float> query=session.createQuery("select max(a.price) from Product a");
		Float p=query.uniqueResult();
		System.out.println("max price:" +p);
		session.close();
		sessionFactory.close();
	}

}
