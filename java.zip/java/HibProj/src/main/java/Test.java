import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
	Product p=session.get(Product.class, 1);
	System.out.println("Id: "+p.getId());
	System.out.println("Description: "+p.getDescription());
	System.out.println("Name : "+p.getName());
	System.out.println("Price: "+p.getPrice());
	session.close();
	sessionFactory.close();
	
	}

}
