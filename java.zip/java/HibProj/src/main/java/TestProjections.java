import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class TestProjections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();

		Query<Object[]> query=session.createQuery("select a.name, a.price from Product a where a.id>10 and a.price> 50");//bind parameters
			
	 List <Object[]> p=query.list();
	System.out.println(p.toString());

for(Object[] o :p)
{
	System.out.println("name: "+o[0]);
	System.out.println("price: "+o[0]);
}
	session.close();
	sessionFactory.close();
	}

}
